package com.example.registertra

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HomeForTrianerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_for_trianer)
    }
}