package com.example.registertra

import android.content.ContentValues.TAG
import android.content.Intent
import android.nfc.Tag
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import android.widget.Toast.makeText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

class RegisterUser : AppCompatActivity() {

    private lateinit var rgsusernameedt: String
    private lateinit var rgspasswordedt: String
    private lateinit var rgsidcardedt: String
    private lateinit var rgsemailedt: String
    private lateinit var rgsfnameedt: String
    private lateinit var rgslnameedt: String
    private lateinit var rgsphonenumedt: String
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_user)

        database =
            FirebaseDatabase.getInstance("https://registertra-default-rtdb.asia-southeast1.firebasedatabase.app")
                .getReference("UserRegister")
        auth = Firebase.auth
        val buttontnrgsU = findViewById<Button>(R.id.btnrgs)
        buttontnrgsU.setOnClickListener {
            saveUserRgs()
        }

    }

    private fun saveUserRgs() {
        val rgsUsername = findViewById<EditText>(R.id.rgsuser)
        val rgsPassWord = findViewById<EditText>(R.id.rgspass)
        val rgsemailaddress = findViewById<EditText>(R.id.rgsemailuser)
        val rgsIDcard = findViewById<TextView>(R.id.rgsidcard)
        val rgsFirstName = findViewById<EditText>(R.id.rgsfname)
        val rgsLastName = findViewById<EditText>(R.id.rgslname)
        val rgsphonenumber = findViewById<EditText>(R.id.rgsphone)
        rgsusernameedt = rgsUsername.text.toString()
        rgspasswordedt = rgsPassWord.text.toString()
        rgsemailedt = rgsemailaddress.text.toString()
        rgsidcardedt = rgsIDcard.text.toString()
        rgsfnameedt = rgsFirstName.text.toString()
        rgslnameedt = rgsLastName.text.toString()
        rgsphonenumedt = rgsphonenumber.text.toString()

        if (rgsusernameedt.isEmpty()) {
            makeText(this, "Please enter your username", Toast.LENGTH_SHORT).show()
        }
        if (rgspasswordedt.isEmpty()) {
            makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show()
        }
        if (rgsemailedt.isEmpty()) {
            makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show()
        }
        if (rgsidcardedt.isEmpty()) {
            makeText(this, "Please enter your idcard", Toast.LENGTH_SHORT).show()
        }
        if (rgsfnameedt.isEmpty()) {
            makeText(this, "Please enter your firstname", Toast.LENGTH_SHORT).show()
        }
        if (rgslnameedt.isEmpty()) {
            makeText(this, "Please enter your lastname", Toast.LENGTH_SHORT).show()
        }
        if (rgsphonenumedt.isEmpty()) {
            makeText(this, "Please enter your PhoneNumber", Toast.LENGTH_SHORT).show()
        } else if (rgsphonenumedt.length != 10) {
            makeText(this, "Please enter your correct PhoneNumber", Toast.LENGTH_SHORT).show()
        } else if (rgsidcardedt.length != 13) {
            makeText(this, "Please enter your IDCard", Toast.LENGTH_SHORT).show()
        } else {
            auth.createUserWithEmailAndPassword(rgsemailedt, rgspasswordedt)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        Log.d("MyApp", "create new User Success!")
                        val userhealthme = auth.currentUser
                        updateUI(userhealthme)
                    } else {
                        Log.w("MyApp", "Failure Signup", task.exception)
                        makeText(this, "Failed", Toast.LENGTH_SHORT).show()
                        updateUI(null)
                    }
                }
                .addOnFailureListener {
                    makeText(baseContext, "Authentication Failed", Toast.LENGTH_SHORT).show()
                }
            val userrgsID = database.push().key
            val UserRGS =
                UserReGis(rgsusernameedt, rgspasswordedt, rgsemailedt, rgsidcardedt, rgsfnameedt, rgslnameedt, rgsphonenumedt)
            if (userrgsID != null) {
                database.child(userrgsID).setValue(UserRGS)
                    .addOnCompleteListener {
                        makeText(this, "Data insert Success", Toast.LENGTH_SHORT).show()
                        val intentrgugobackhome = Intent(this, HomeActivity::class.java)
                        startActivity(intentrgugobackhome)
                    }.addOnFailureListener { err ->
                        makeText(this, "ERROR ${err.message}", Toast.LENGTH_SHORT).show()
                    }
            }
        }
    }

    private fun updateUI(userhealthme: FirebaseUser?) {
        if (userhealthme != null) {
            return
        }
    }
}