package com.example.registertra

data class UserReGis(
    var usernameR:String? = null, var passwordR: String?, var emailR:String? = null, var idcardR:String?,
    var firstnameR:String? = null, var lastnameR:String? = null, var phonenumberR:String? = null) {
}