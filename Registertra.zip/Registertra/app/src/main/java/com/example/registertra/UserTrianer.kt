package com.example.registertra

data class UserTrianer(
    var usernameM:String? = null, var passwordM: String?, var emailM:String? = null, var idcardM:String?,
    var firstnameM:String? = null, var lastnameM:String? = null, var phonenumberM:String? = null){

}